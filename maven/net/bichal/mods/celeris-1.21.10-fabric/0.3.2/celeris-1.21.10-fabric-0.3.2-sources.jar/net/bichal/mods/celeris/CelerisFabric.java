//? if fabric {
package net.bichal.mods.celeris;

import net.bichal.mods.celeris.config.CelerisFabricConfig;
import net.bichal.mods.celeris.network.NetworkRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;

/**
 * Mod entry points on Fabric (fabric.mod.json: "main" and "client"). The same
 * startup as NeoForge's {@link Celeris}: the config file, backend selection,
 * then the network channel.
 */
public final class CelerisFabric implements ModInitializer, ClientModInitializer {

    @Override
    public void onInitialize() {
        CelerisFabricConfig.load();
        Celeris.start();
        NetworkRegistry.register();
    }

    @Override
    public void onInitializeClient() {
        NetworkRegistry.registerClient();
    }
}
//?}
